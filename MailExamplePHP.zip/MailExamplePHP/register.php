<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


	<div class="container jumbotron">
		
		<center><h1>Registration</h1></center>
		<hr>
		<br>
		<form method="post">
		<label>Fullname</label>
		<input type="text" class="form-control" name="fullname">
		<br>		
		
		<label>Gender</label><br>
		<input type="radio" name="gender" value="male"> Male
		<input type="radio" name="gender" value="female"> Female<br>
		<br>
		
		<label>Email ID</label>
		<input type="text" class="form-control" name="emailid">
		<br>

		<label>Password</label>
		<input type="text" class="form-control" name="password">
		<br>

		<input type="submit" class="btn btn-primary btn-lg" value="Register" name="sub_btn">
		</form>
	</div>


	<?php 

	if(isset($_POST['sub_btn']))
	{
		$fullname = $_POST['fullname'];
		$emailid = $_POST['emailid'];
		$gender = $_POST['gender'];
		$password = $_POST['password'];


			
		    include_once 'PHPMailer/src/PHPMailer.php';
	            include_once 'PHPMailer/src/Exception.php';
	            include_once 'PHPMailer/src/SMTP.php';
	      

	            $mail = new PHPMailer\PHPMailer\PHPMailer();
	            
	            //$mail->SMTPDebug = 3; //For Debugging
	            $from="noreply@gmail.com";
	            $mail->Host = "smtp.gmail.com";
	            
	            $mail->isSMTP();
	            $mail->SMTPAuth = true;
	            #Email of sender
	            $mail->Username = "dummymail5501@gmail.com";
	            $mail->Password = "ashvin709012";
	            $mail->SMTPSecure = "ssl"; 
	            $mail->Port = 465;

	            $mail->setFrom($from);
	            #Reciever Emailid
	            $mail->addAddress($emailid); 
	            $mail->Subject = "Registered Successfully";
	            $mail->isHTML(true);
	            $mail->Body = "Hello $fullname, <br>You Are Registered Successfully On VTPBCA.com"; 

	            if($mail->Send())
	            {
	                echo "Message Sent";
	            }
	            else
	            {
	                echo "Mail Error: ".$mail->ErrorInfo;
	            }
	}

	 ?>



